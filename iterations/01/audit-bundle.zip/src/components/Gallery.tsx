import React from 'react';
import { Image as ImageIcon } from 'lucide-react';

export const Gallery: React.FC = () => {
  // Placeholder data for the gallery
  const items = [1, 2, 3, 4, 5, 6];

  return (
    <div className="min-h-screen bg-white pt-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-12">
           <h1 className="text-4xl font-bold tracking-tight mb-4">Gallery</h1>
           <div className="w-20 h-1 bg-brand-black mb-6"></div>
           <p className="text-gray-500 max-w-2xl">
             A visual journal of workshops, whiteboarding sessions, and events.
           </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-24">
          {items.map((item) => (
            <div key={item} className="aspect-square bg-gray-100 rounded-2xl overflow-hidden group relative cursor-pointer">
              {/* Placeholder Content */}
              <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-300 group-hover:text-brand-blue transition-colors">
                 <ImageIcon size={48} strokeWidth={1} />
                 <span className="mt-4 font-mono text-xs uppercase tracking-widest">Image {item}</span>
              </div>
              
              {/* Hover Overlay */}
              <div className="absolute inset-0 bg-brand-black/0 group-hover:bg-brand-black/5 transition-colors duration-300"></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};