import React from 'react';
import { ModuleWrapper } from '../ModuleWrapper';
import { M5_QUESTIONS } from '../../constants';
import { ShieldAlert, ShieldCheck } from 'lucide-react';
import { ProficiencyTrack } from '../../types';
import { VideoHero } from '../VideoHero';

export const Module5: React.FC<{onComplete: (s: number)=>void, track?: ProficiencyTrack}> = ({onComplete, track}) => {
  return (
    <ModuleWrapper 
      title="Data Security" 
      moduleId={5} 
      onComplete={onComplete} 
      quizQuestions={M5_QUESTIONS} 
      track={track}
      hero={
        <VideoHero 
          moduleId={5}
          title="Data Security"
          subtitle="The No-Go List"
          description="A single data leak is catastrophic. Finley's junior consultant almost pasted a confidential M&A deal into a public tool. Security isn't an IT problem; it's a prompt engineering problem."
          imageKeyword="cyber security"
        />
      }
    >
       
       {/* Why This Matters */}
      <section className="mb-12">
         <h2 className="text-xl font-bold text-brand-black mb-4 flex items-center gap-2">
            <span className="w-8 h-8 rounded-full bg-brand-black text-white flex items-center justify-center text-sm">05</span>
            Context
         </h2>
         <div className="bg-white border-l-4 border-brand-orange p-6 shadow-clean rounded-r-xl mb-6">
            <p className="text-gray-700 italic mb-4">
              "She's drafting a proposal for a confidential M&A deal. To save time, she pastes the entire briefing document into a public AI tool. That data may now be used to train the model."
            </p>
         </div>
      </section>

       <section className="prose max-w-none mb-8">
        <h3>The No-Go List</h3>
        <p>If you are using a public model (like the free version of ChatGPT or Gemini), your data may be used to train future models.</p>
      </section>

      <div className="bg-red-50 border-l-8 border-brand-red rounded-r-xl p-8 shadow-sm mb-8">
        <h3 className="text-brand-red font-bold text-xl flex items-center gap-2 mb-6">
          <ShieldAlert /> NEVER share with public AI:
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            "Full names + sensitive context",
            "Financial account numbers",
            "Passwords or credentials",
            "Client-identifiable details",
            "Proprietary code/formulas",
            "Health information"
          ].map(item => (
            <div key={item} className="flex items-center gap-3 bg-white p-3 rounded shadow-sm">
               <div className="w-2 h-2 rounded-full bg-brand-red"></div>
               <span className="font-medium text-gray-800">{item}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-green-50 p-6 rounded-xl border border-green-200">
        <h3 className="font-bold text-brand-green flex items-center gap-2 mb-2">
          <ShieldCheck /> Safe Practice: Anonymization
        </h3>
        <p className="text-sm text-gray-700">
          Instead of "Client Acme Corp needs a Q3 strategy", use "Client A (Large Retailer) needs a quarterly strategy".
        </p>
      </div>
    </ModuleWrapper>
  );
};