import React, { useState } from 'react';
import { PortfolioLayout } from './components/PortfolioLayout';
import { PortfolioHome } from './components/PortfolioHome';
import { About } from './components/About';
import { SkillsAtlas } from './components/SkillsAtlas';
import { AITeacherApp } from './components/AITeacherApp';
import { Gallery } from './components/Gallery';
import { Timeline } from './components/Timeline';

type View = 'about' | 'works' | 'gallery' | 'skills-atlas' | 'ai-teacher' | 'timeline';

function App() {
  const [currentView, setCurrentView] = useState<View>('about');

  // If viewing the AI Teacher App, we render it full screen (it has its own layout)
  if (currentView === 'ai-teacher') {
    return <AITeacherApp onExit={() => setCurrentView('works')} />;
  }

  // Otherwise, render the Portfolio Layout
  return (
    <PortfolioLayout onNavigate={(page) => setCurrentView(page as View)} currentPage={currentView}>
      {currentView === 'about' && <About />}
      {currentView === 'works' && <PortfolioHome onNavigate={(page) => setCurrentView(page as View)} />}
      {currentView === 'gallery' && <Gallery />}
      {currentView === 'skills-atlas' && <SkillsAtlas />}
      {currentView === 'timeline' && <Timeline />}
    </PortfolioLayout>
  );
}

export default App;