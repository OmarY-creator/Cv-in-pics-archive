import React from 'react';
import { ModuleWrapper } from '../ModuleWrapper';
import { M4_QUESTIONS } from '../../constants';
import { Globe, Clock } from 'lucide-react';
import { ProficiencyTrack } from '../../types';
import { VideoHero } from '../VideoHero';

export const Module4: React.FC<{onComplete: (s: number)=>void, track?: ProficiencyTrack}> = ({onComplete, track}) => {
  return (
    <ModuleWrapper 
      title="Web-Grounding" 
      moduleId={4} 
      onComplete={onComplete} 
      quizQuestions={M4_QUESTIONS} 
      track={track}
      hero={
        <VideoHero 
          moduleId={4}
          title="Web-Grounding"
          subtitle="Static vs. Dynamic Knowledge"
          description="Finley's consultants need today's regulations, not last year's. BrightCart needs real-time stock levels. Static models are frozen in time; Grounding connects them to the present."
          imageKeyword="global network"
        />
      }
    >
       
       {/* Why This Matters */}
      <section className="mb-12">
         <h2 className="text-xl font-bold text-brand-black mb-4 flex items-center gap-2">
            <span className="w-8 h-8 rounded-full bg-brand-black text-white flex items-center justify-center text-sm">04</span>
            Context
         </h2>
         <div className="bg-white border-l-4 border-brand-orange p-6 shadow-clean rounded-r-xl mb-6">
            <p className="text-gray-700 italic mb-4">
              "A consultant advises a client on new regulations that came into effect three months ago. The AI confidently explains the old framework. Because that's all it knows."
            </p>
         </div>
      </section>

       <section className="prose max-w-none mb-8">
        <h3>Static vs. Dynamic Knowledge</h3>
        <p>Most models have a "knowledge cutoff". They don't know what happened today unless they use tools to search the web. This is called Grounding.</p>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-lg border-t-4 border-gray-400">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-gray-100 p-3 rounded-full"><Clock className="text-gray-600"/></div>
            <h3 className="font-bold text-lg">Non-Grounded</h3>
          </div>
          <ul className="space-y-2 text-sm text-gray-600">
            <li className="flex gap-2">✅ Creative writing</li>
            <li className="flex gap-2">✅ Analyzing pasted text</li>
            <li className="flex gap-2">✅ Coding help</li>
            <li className="flex gap-2 text-brand-red">❌ Checking stock prices</li>
            <li className="flex gap-2 text-brand-red">❌ Recent news events</li>
          </ul>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-lg border-t-4 border-brand-green">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-green-100 p-3 rounded-full"><Globe className="text-brand-green"/></div>
            <h3 className="font-bold text-lg">Web-Grounded</h3>
          </div>
          <ul className="space-y-2 text-sm text-gray-600">
            <li className="flex gap-2">✅ Competitor research</li>
            <li className="flex gap-2">✅ Citing sources</li>
            <li className="flex gap-2">✅ Recent regulations</li>
            <li className="flex gap-2 text-brand-orange">⚠️ May hallucinate sources</li>
            <li className="flex gap-2 text-brand-orange">⚠️ Slower response time</li>
          </ul>
        </div>
      </div>
    </ModuleWrapper>
  );
};